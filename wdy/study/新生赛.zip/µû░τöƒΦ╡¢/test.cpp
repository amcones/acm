/***********************************
// @Author   :   amcones
// @Problem  :   uli的迷宫.cpp
// @When     :   2021-11-22 10:20:51
***********************************/
#include <cstring>
#include <iostream>
#include <queue>
using namespace std;
using ll = long long;
using PII = pair<int, int>;
using PLL = pair<ll, ll>;
const int maxn = 6e2 + 10;
char mp[maxn][maxn];
bool vis[maxn][maxn];
int step[maxn][maxn];
int dir[4][2] = {1, 0, -1, 0, 0, 1, 0, -1};
int n, m;
int S = 0x3f3f3f3f, Y = 0;
void bfs(PII r) {
    queue<PII> q;
    q.push(r);
    vis[r.first][r.second] = true;
    while (!q.empty()) {
        PII s = q.front();
        q.pop();
        for (int i = 0; i < 4; i++) {
            int tx = s.first + dir[i][0], ty = s.second + dir[i][1];
            if (mp[tx][ty] == '#' || vis[tx][ty])
                continue;
            if (mp[tx][ty] == 'G')
                Y++;
            vis[tx][ty] = true;
            step[tx][ty] = step[s.first][s.second] + 1;
            if (tx < 1 || tx > n || ty < 1 || ty > m) {
                S = step[tx][ty];
                return;
            }
            q.push({tx, ty});
        }
    }
}
int main() {
    freopen("56.in", "r", stdin);
    S = 0x3f3f3f3f, Y = 0;
    cin >> n >> m;
    int sx, sy;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) {
            cin >> mp[i][j];
            if (mp[i][j] == 'U')
                sx = i, sy = j;
        }
    // assert(!(sx > 500 || sy > 500 || sx < 0 || sy < 0));
    step[sx][sy] = 0;
    bfs({sx, sy});
    if (S != 0x3f3f3f3f)
        cout << S << ' ' << Y << endl;
    else
        cout << -1 << endl;
    return 0;
}